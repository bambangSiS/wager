<?php
// Start the session
session_start();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>HighLow - BTC, DOGE, BTT, SHIB, AOA, SAITAMA, FLOKI, BUFFDOGE, YOOSHI, RACA, BABYDOGE, DOGEZILLA.</title>
    <link rel="shortcut icon" href="assets/img/hilo.png">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<style>

/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #27313d;
  color:white;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}
</style>

<body>
    <header>
        <div class="container-fluid bg-dark">
            <div class="box-link"><a class="link-header active" href="#">BTC</a><a class="link-header" href="#">DOGE</a><a class="link-header" href="#">BTT</a><a class="link-header" href="#">SHIB</a><a class="link-header" href="#">SAITAMA</a><a class="link-header" href="#">FLOKI</a><a class="link-header" href="#">BUFFDOGE</a><a class="link-header" href="#">YOOSHI</a><a class="link-header" href="#">RACA</a><a class="link-header" href="#">BABYDOGE</a><a class="link-header" href="#">DOGEZILLA</a></div>
        </div>
    </header>
    <div class="container container-style">
        <div class="row ml-n1 mr-n1">
            <div class="col col-4 p-0"><label class="fs-lg">AMOUNT</label><input type="text" class="form-control fs-lg input-lg" value="2000" align="right"></div>
            <div class="col col-8 p-1"><label class="d-block fs-lg" align="center">WIN&nbsp;PROFIT</label>
                <h1 class="m-0 text-success" align="center">1258.61569785 Doge</h1>
            </div>
        </div>
        <div class="row ml-n1 mr-n1 justify-content-center">
            <div class="col col-lg-6 col-md-6 col-sm-4 col-xs-4 col-4 p-1"><label class="col-form-label fs-lg d-block" align="center">Choice to win</label></div>
            <div class="col col-lgcol-lg-3 col-md-3 col-sm-4 col-xs-4 col-4 p-1"><label class="col-form-label fs-lg d-block" align="center">Wager</label></div>
            <div class="col col-lgcol-lg-3 col-md-3 col-sm-4 col-xs-4 col-4 p-1"><label class="col-form-label fs-lg d-block" align="center">Chance</label></div>
        </div>
        <div class="row ml-n1 mr-n1 bg-dark justify-content-center radius-20 pt-lg-3 pb-lg-3 border-3">
            <div class="col col-lg-6 col-md-6 col-sm-4 col-xs-4 col-4 p-1 border-right pt-2 pb-2 pt-lg-2" align="center">
                <div align="center"><button class="btn btn-dark fs-lg btn-over d-block mb-3 mt-1" type="button">OVER</button><button class="btn btn-dark fs-lg btn-over d-block text-warning" type="button">UNDER</button></div>
            </div>
            <div class="col col-lg-3 col-md-3 col-sm-4 col-xs-4 col-4 p-1 border-right d-flex align-items-center justify-content-around">
                <div class="pt-2 pb-2 w-100">
                    <div class="w-100" align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Min</span><span class="d-block">A</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">Max</span><span class="d-block">D</span></a></div>
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Reset</span><span class="d-block">W</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">10%</span><span class="d-block">X</span></a></div>
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Double</span><span class="d-block">S</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">Half</span><span class="d-block">Z</span></a></div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-3 col-sm-4 col-xs-4 col-4 p-1 d-flex align-items-center justify-content-around">
                <div class="w-100">
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Min</span><span class="d-block">R</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">Max</span><span class="d-block">Y</span></a></div>
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Reset</span><span class="d-block">T</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">10%</span><span class="d-block">F</span></a></div>
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Double</span><span class="d-block">G</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">Half</span><span class="d-block">V</span></a></div>
                </div>
            </div>
        </div>
        <div class="row ml-n1 mr-n1 mt-2">
            <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6 fs-lg d-flex justify-content-between align-items-center pl-1 pr-1" align="center"><label align="left">Chance %<br>to win</label><input type="text" class="form-control-lg chance-input" value="0"></div>
            <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6 pr-1 fs-lg pl-3" align="left"><label>Curl up</label>
                <div class="progress">
                    <div id="rangeprogressbar" class="progress-bar bg-warning" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 20%;">20%</div>
                </div>
            </div>
        </div>
        <div class="tab">
          <button class="tablinks" onclick="openmenu(event, 'AllBet')">AllBet</button>
          <button class="tablinks" onclick="openmenu(event, 'Account')">Account</button>
          <button class="tablinks" onclick="openmenu(event, 'Histories')">Histories</button>
          <button class="tablinks" onclick="openmenu(event, 'My Stake')">My Stake</button>
          <button class="tablinks" onclick="openmenu(event, 'Svr24')">Svr24</button>
          <button class="tablinks" onclick="openmenu(event, 'Deposit')">Deposit</button>
          <button class="tablinks" onclick="openmenu(event, 'Withdraw')">Withdraw</button>
          <button class="tablinks" onclick="openmenu(event, 'Refferal')">Refferal</button>
          <button class="tablinks" onclick="openmenu(event, 'Bonus')">Bonus</button>
          <button class="tablinks" onclick="openmenu(event, 'Random Bonus')">Random Bonus</button>
          <button class="tablinks" onclick="openmenu(event, 'Report')">Report</button>
          <button class="tablinks" onclick="openmenu(event, 'High Stake')">High Stake</button>
        </div>

        <div id="AllBet" class="tabcontent">
          <table class="table">
                    <thead>
                        <tr>
                            <th>Player</th>
                            <th>Number</th>
                            <th>Target</th>
                            <th>Bet Size</th>
                            <th>Profit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Crinis (123123123)</td>
                            <td class="text-success">90.50<span class="small-td">12</span></td>
                            <td>&gt;04.99<span class="small-td">12</span></td>
                            <td>0.8823823882 Doge</td>
                            <td class="text-danger">-0.00000123</td>
                        </tr>
                        <tr>
                            <td>Nicarette (3434123123)<br></td>
                            <td class="text-danger">[Wins : 1/1]</td>
                            <td>&gt;04.99<span class="small-td">12</span></td>
                            <td>0.8823823882 Doge</td>
                            <td class="text-success">0.00000123</td>
                        </tr>
                    </tbody>
                </table>
        </div>
                
        <div id="Account" class="tabcontent">
            <?php $ceklogin = isset ($_SESSION["userloginhighlow"]) ? $_SESSION["userloginhighlow"]:'';?>
            <?php if($ceklogin==''){?>
            <!--sign in-->
           <div class="text-center text-muted mb-4"><small>Please Sign in<br></small></div>
				<form method="post" enctype="multipart/form-data"> 
                    <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="text" name="username" placeholder="User Name">
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <div class="input-group input-group-alternative text-black">
                            <div class="input-group-prepend"><span class="input-group-text"><i class="la la-unlock m-0"></i></span></div>
							<input class="form-control" type="password" name="password" placeholder="Password">
                        </div>
                    </div>
                    <div class="custom-control custom-control-alternative custom-checkbox"><input type="checkbox" id="customCheckLogin" class="custom-control-input"><label class="custom-control-label" for="customCheckLogin"><span>Remember me<br></span></label></div>
                    <div class="text-center"><button class="btn btn-dark btn-min" name="login" type="button">Login</button></div>
                </form>
                <div class="row mt-3">
                    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6"><a href="#"><small class="text-light">Forgot Password<br></small></a></div>
                    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6" align="right"><a href="register"><small class="text-light">Create new account<br></small></a></div>
                </div>
                
            <!--signup-->
            <div class="text-center text-muted mb-4"><small>First Time<br></small></div>
				<form method="post" enctype="multipart/form-data"> 
				     <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="text" name="displayname" placeholder="Display Name" 
								value="<?php
                                        $a=array("Martha","Steven","Andreas","Jhon","Peter");
                                        $random_keys=array_rand($a,3);
                                        echo $a[$random_keys[0]];
                                        ?>">
                        </div>
                    </div>
                    <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="text" name="username" placeholder="User Name">
                        </div>
                    </div>
                     <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="email" name="email" placeholder="email">
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <div class="input-group input-group-alternative text-black">
                            <div class="input-group-prepend"><span class="input-group-text"><i class="la la-unlock m-0"></i></span></div>
							<input class="form-control" type="password" name="password" placeholder="Password">
                        </div>
                    </div>
                    <div class="text-center"><button class="btn btn-dark btn-min" name="login" type="button">Signin</button></div>
                </form>
                <div class="row mt-3">
                    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6"><a href="#"><small class="text-light">Forgot Password<br></small></a></div>
                    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6" align="right"><a href="register"><small class="text-light">Have Account?sign in<br></small></a></div>
                </div>
                
                <!--forgot password-->
           <div class="text-center text-muted mb-4"><small>Send me Password?<br></small></div>
				<form method="post" enctype="multipart/form-data"> 
                    <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="email" name="email" placeholder="your email">
                        </div>
                    </div>
                    <div class="text-center"><button class="btn btn-dark btn-min" name="login" type="button">send</button></div>
                </form>
                <div class="row mt-3">
                    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6"><a href="#"><small class="text-light">Sign in<br></small></a></div>
                    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6" align="right"><a href="register"><small class="text-light">Create new account<br></small></a></div>
                </div>
                <?php }else{?>
                
                
                <?php }?>
        </div>
        
        <div id="Histories" class="tabcontent">
          <table class="table">
                    <thead>
                        <tr>
                            <th>Player</th>
                            <th>Number</th>
                            <th>Target</th>
                            <th>Bet Size</th>
                            <th>Profit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Crinis (123123123)</td>
                            <td class="text-success">90.50<span class="small-td">12</span></td>
                            <td>&gt;04.99<span class="small-td">12</span></td>
                            <td>0.8823823882 Doge</td>
                            <td class="text-danger">-0.00000123</td>
                        </tr>
                        <tr>
                            <td>Nicarette (3434123123)<br></td>
                            <td class="text-danger">[Wins : 1/1]</td>
                            <td>&gt;04.99<span class="small-td">12</span></td>
                            <td>0.8823823882 Doge</td>
                            <td class="text-success">0.00000123</td>
                        </tr>
                    </tbody>
                </table>
        </div>
        
        <div id="My Stake" class="tabcontent">
          <h3>Tokyo</h3>
          <p>Tokyo is the capital of Japan.</p>
        </div>

    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script>
    
    // Update the count down every 1 second
    var x = setInterval(function() {
        var randomnumber=Math.floor(Math.random() * 100);
        document.getElementById("rangeprogressbar").style.width =randomnumber.toString()+"%"
        document.getElementById("rangeprogressbar").innerHTML =randomnumber
    }, 1000);
                
    </script>
        
        
    <script>
    function openmenu(evt, cityName) {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }
    </script>
</body>

</html>