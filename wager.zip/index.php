<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Wager</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="container container-style">
        <div class="row ml-n1 mr-n1">
            <div class="col col-4 p-0"><label class="fs-lg">AMOUNT</label><input type="text" class="form-control fs-lg input-lg" value="2000" align="right"></div>
            <div class="col col-8 p-1"><label class="d-block fs-lg" align="center">WIN&nbsp;PROFIT</label>
                <h1 class="m-0 text-success" align="center">1258.61569785 Doge</h1>
            </div>
        </div>
        <div class="row ml-n1 mr-n1 justify-content-center">
            <div class="col col-lg-6 col-md-6 col-sm-4 col-xs-4 col-4 p-1"><label class="col-form-label fs-lg d-block" align="center">Choice to win</label></div>
            <div class="col col-lgcol-lg-3 col-md-3 col-sm-4 col-xs-4 col-4 p-1"><label class="col-form-label fs-lg d-block" align="center">Wager</label></div>
            <div class="col col-lgcol-lg-3 col-md-3 col-sm-4 col-xs-4 col-4 p-1"><label class="col-form-label fs-lg d-block" align="center">Chance</label></div>
        </div>
        <div class="row ml-n1 mr-n1 bg-dark justify-content-center radius-20 pt-lg-3 pb-lg-3 border-3">
            <div class="col col-lg-6 col-md-6 col-sm-4 col-xs-4 col-4 p-1 border-right pt-2 pb-2 pt-lg-2" align="center">
                <div align="center"><button class="btn btn-dark fs-lg btn-over d-block mb-3 mt-1" type="button">OVER</button><button class="btn btn-dark fs-lg btn-over d-block text-warning" type="button">UNDER</button></div>
            </div>
            <div class="col col-lg-3 col-md-3 col-sm-4 col-xs-4 col-4 p-1 border-right d-flex align-items-center justify-content-around">
                <div class="pt-2 pb-2 w-100">
                    <div class="w-100" align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Min</span><span class="d-block">A</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">Max</span><span class="d-block">D</span></a></div>
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Reset</span><span class="d-block">W</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">10%</span><span class="d-block">X</span></a></div>
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Double</span><span class="d-block">S</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">Half</span><span class="d-block">Z</span></a></div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-3 col-sm-4 col-xs-4 col-4 p-1 d-flex align-items-center justify-content-around">
                <div class="w-100">
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Min</span><span class="d-block">R</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">Max</span><span class="d-block">Y</span></a></div>
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Reset</span><span class="d-block">T</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">10%</span><span class="d-block">F</span></a></div>
                    <div align="center"><a class="btn btn-dark btn-min" role="button"><span class="d-block">Double</span><span class="d-block">G</span></a><a class="btn btn-dark btn-min" role="button"><span class="d-block">Half</span><span class="d-block">V</span></a></div>
                </div>
            </div>
        </div>
        <div class="row ml-n1 mr-n1 mt-2">
            <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6 fs-lg d-flex justify-content-between align-items-center pl-1 pr-1" align="center"><label align="left">Chance %<br>to win</label><input type="text" class="form-control-lg chance-input" value="0"></div>
            <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6 pr-1 fs-lg pl-3" align="left"><label>Speed Wager</label>
                <div class="progress">
                    <div class="progress-bar bg-warning" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 20%;">20%</div>
                </div>
            </div>
        </div>
        <div class="row ml-n1 mr-n1 mt-2">
            <div class="col col-6 p-1" align="center"><button class="btn btn-dark text-danger btn-block btn-play" type="button">Play Off</button></div>
            <div class="col col-6 p-1" align="center"><button class="btn btn-dark text-success btn-block btn-play" type="button">Stop On Win</button></div>
        </div>
        <div class="pt-3 mt-4 border">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Player</th>
                            <th>Number</th>
                            <th>Target</th>
                            <th>Bet Size</th>
                            <th>Profit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Crinis (123123123)</td>
                            <td class="text-success">90.50<span class="small-td">12</span></td>
                            <td>&gt;04.99<span class="small-td">12</span></td>
                            <td>0.8823823882 Doge</td>
                            <td class="text-danger">-0.00000123</td>
                        </tr>
                        <tr>
                            <td>Nicarette (3434123123)<br></td>
                            <td class="text-danger">[Wins : 1/1]</td>
                            <td>&gt;04.99<span class="small-td">12</span></td>
                            <td>0.8823823882 Doge</td>
                            <td class="text-success">0.00000123</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script>
            
    setInterval(console.log( Math.floor(Math.random() * 100)
        ), 1000);
            
    </script>
</body>

</html>