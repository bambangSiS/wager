
<?php
class Library
{
    public function __construct()
    {
        $host = "localhost";
        $dbname = "hghlw675_baseon";
        $username = "hghlw675_hghlw675";
        $password = "AJ.IK7DT6xHh";
        $this->db = new PDO("mysql:host={$host};dbname={$dbname}", $username, $password);
    }
    
    public function add(){
        
      //
    }
}