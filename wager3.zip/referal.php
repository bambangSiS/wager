<section> 
	 
	
	<div class="container bg-white min-vh-100 pt-3 pb-5">
		<div class="p-2 table-style">
		
		
		
		<div class="">
			
			<h4 class="mb-1"> Referral  </h4> 
			<p class="mb-0">   List Your Referral  - You Can share this link for get referral <br>
			Your Referral Code = bambang  </p> 
			
			
		<div class="row ml-n2 mr-n2">
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-12  p-2">
				<a class="card-deposit" href="#" align="center">
                        <div class="">
						<h1 class="d-block"> 0</h1>  
						<span>Total Referral</span> 
						
						
						</div>
                </a>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-12  p-2">
				<a class="card-deposit" href="#" align="center">
                        <div class="">
						<h1 class="d-block"> 0</h1> 
						<span>Total Downline</span> 
						
						</div>
                </a>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-12  p-2">
				<a class="card-deposit" href="#" align="center">
                        <div class="">
						<h1 class="d-block"> 0</h1> 
						<span>Level Bonus</span> 
						
						</div>
                </a>
				</div>
				
		</div>
		
			
			<hr>
			 <div class="row"> 
			 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12  ">
						<link rel="stylesheet" href="https://riddle.dream888.net/assets/datatables/datatables.min.css">
						<link rel="stylesheet" href="https://riddle.dream888.net/assets/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
						<link rel="stylesheet" href="https://riddle.dream888.net/assets/datatables/Select-1.2.4/css/select.bootstrap4.min.css">  
						 
										<div class="table-responsive">
											<div id="tables_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer"><div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="tables_length"><label>Show <select name="tables_length" aria-controls="tables" class="form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="tables_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="tables"></label></div></div></div><div class="row"><div class="col-sm-12"><table id="tables" class="table table-striped dataTable no-footer" role="grid" aria-describedby="tables_info" style="width: 727px;">
												<thead>
												<tr role="row"><th class="sorting_desc" tabindex="0" aria-controls="tables" rowspan="1" colspan="1" aria-sort="descending" aria-label="Date: activate to sort column ascending" style="width: 63px;">Date</th><th class="sorting" tabindex="0" aria-controls="tables" rowspan="1" colspan="1" aria-label="Name: activate to sort column ascending" style="width: 75px;">Name</th><th class="sorting" tabindex="0" aria-controls="tables" rowspan="1" colspan="1" aria-label="Total Referral: activate to sort column ascending" style="width: 147px;">Total Referral</th><th class="sorting" tabindex="0" aria-controls="tables" rowspan="1" colspan="1" aria-label="Total Downline: activate to sort column ascending" style="width: 164px;">Total Downline</th><th class="sorting" tabindex="0" aria-controls="tables" rowspan="1" colspan="1" aria-label="Level: activate to sort column ascending" style="width: 66px;">Level</th></tr>
												</thead>
											<tbody><tr class="odd"><td valign="top" colspan="5" class="dataTables_empty">No matching records found</td></tr></tbody></table><div id="tables_processing" class="dataTables_processing card" style="display: none;">Processing...</div></div></div><div class="row"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="tables_info" role="status" aria-live="polite">Showing 0 to 0 of 0 entries (filtered from 7 total entries)</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="tables_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="tables_previous"><a href="#" aria-controls="tables" data-dt-idx="0" tabindex="0" class="page-link">Previous</a></li><li class="paginate_button page-item next disabled" id="tables_next"><a href="#" aria-controls="tables" data-dt-idx="1" tabindex="0" class="page-link">Next</a></li></ul></div></div></div></div> 
										</div> 

						<script src="https://riddle.dream888.net/assets/datatables/datatables.min.js"></script>
						<script src="https://riddle.dream888.net/assets/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
						<script src="https://riddle.dream888.net/assets/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>


						<script>  
						site ="https://riddle.dream888.net/";
						$(document).ready(function() {
						var tablex = $('#tables').dataTable( {
						 "bProcessing": true,
						 "bServerSide": true, 
						  
						 "order": [[0,'desc']], 
							"ajax" : { 
								url:  site+"server/referral.php?id=1) ;  ?>", 
								type:"POST"
							} ,
							
						 "aoColumns": [
							
							null,
							null,
							null,
							null,
							null,
							
							
							
						 ]
						 } );
						 
						 } );
						 
						 
						 
						function table_reload(){
							$('#tables').DataTable().ajax.reload(null, false);
						}
						 

						</script> 

							
					
					 
		</div>
		</div>
		</div>
		</div>
	
	</div>
	

</section>