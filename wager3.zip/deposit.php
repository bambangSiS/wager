<section>
        
        <div class="container mt-4 mb-4 radius-border bg-white pt-3 pb-3" id="payment">
            
                          <h4 class="text-monospace" align="center">Select Payment Method</h4>
            <hr>
            <div class="row ml-n2 mr-n2 " id="select_payment_index">
                <div class="container">
                  <div class="row">
                    <div class="col-sm col-md-3">
                      
    					    <a class="card-deposit" href="#" onclick="open_select('payment era')">
                                <div><img src="assets/img/pngwing.com.png " style="width:50px;height:50px;"></div>
                            </a>
                    </div>
                    <div class="col-sm">
                        <span>Debosit via Bank wire, credit card and e-wallet</span>
                      Deposit via bank wire, credit card and e-wallet, View available payment method.
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm col-md-3">
                      
    				        <a class="card-deposit" href="#" onclick="open_select('crypto payment')">
                                <div><img src="assets/img/cryptocurrenc.png" style="width:50px;height:50px;"></div>
                            </a>
                    </div>
                    <div class="col-sm">
                        <label>Deposit cryptocurrencies</label>
                      We Accept the following cryptocurrencies.
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm col-md-3">
                     
        				<a class="card-deposit" href="#" onclick="open_select('agent payment')">
                                <div><img src="assets/img/agentpayment.png" style="width:50px;height:50px;"></div>
                        </a>
                    </div>
                    <div class="col-sm">
                        <label>Deposit via payment agents</label>
                      Deposit in your local currency via an authorised,independent payment agent in your country.
                    </div>
                  </div>
                </div>
            </div>
            
            <div class="row ml-n2 mr-n2 d-none" id="select_payment">
			
                <div class="col col-lg-3 col-md-3 col-sm-6 col-xs-6 col-6 p-2">
					<a class="card-deposit" href="#" onclick="open_visa()">
                        <div><img src="assets/img/Visa_Inc._logo.svg.png"><span>Debit / Credit Card</span></div>
                    </a>
				</div>
					
                <div class="col col-lg-3 col-md-3 col-sm-6 col-xs-6 col-6 p-2">
				<a class="card-deposit" href="#" onclick="open_bank('assets/img/mandiri.png','Riddle_Agent','8932510000006666','Bank Mandiri','Please make delivery via the Bank above, and enter proof of payment in the form below')">
                        <div><img src="assets/img/mandiri.png"><span>Bank Mandiri</span></div>
                </a>
				</div>
                
				
            </div>
            
            <div class="row ml-n2 mr-n2 d-none" id="select_payment2">
                
				<div class="col col-lg-3 col-md-3 col-sm-6 col-xs-6 col-6 p-2">
				<a class="card-deposit" href="#" onclick="open_bank('assets/img/accepted_diamond.png','Diamond (BEP20)','0xb6Bf19599724e52b3847716CC4c01b6040a51757','DMX','Please make delivery via the Crypto above, and enter proof of payment in the form below')">
                        <div><img src="assets/img/accepted_diamond.png"><span>Diamond (DMX)</span></div>
                </a>
				</div>
                
				
            </div>
			
            <div id="form_payment" class="d-none">
                <div class="row">
                    <div class="col col-lg-3 col-md-3 col-sm-12 col-xs-12 col-12">
					<a class="card-deposit" href="#">
                            <div><img class="table_logo" src="assets/img/mandiri.png"><span class="table_bank"></span></div>
                    </a>
					
					<a class="d-block text-danger text-center" href="#" onclick="change_payment()">Change</a>
					<a class="d-block text-info text-center" href="#" onclick="change_close()">Close</a></div>
                    <div class="col col-lg-9 col-md-9 col-sm-12 col-xs-12 col-12">
                        <h4 class="mb-0">Deposit Form</h4>
                        <p>Please make payment according to the instructions below</p>
                        <div class="table-responsive table-borderless text-dark">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Simbol</th>
                                        <th>Network</th>
                                        <th>Address</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="table_bank"></td>
                                        <td class="table_name"></td>
                                        <!--<td class="table_number"></td>-->
                                        <td><input class="kaj" type="text" value="" id="copyText" readonly="">
                                            <button class="btn btn-primary mt-2" id="copyBtn">Copy</button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <p class="caption_payment">Please make delivery via the Crypto above, and enter proof of payment in the form below</p>
                        <hr>
                        <form action="" method="post" enctype="multipart/form-data">
                             <div class="pb-2" id="amountdmx" style="display:true;"><label class="mb-0">Total Deposit</label><input type="text" class="form-control" name="amount" placeholder="DMX."></div>
                             <div class="pb-2" id="amountrp" style="display:true;"><label class="mb-0">Total Deposit</label><input type="text" class="form-control" name="amountrp" placeholder="Rp."></div>
                             <div class="pb-2" id="hashidtx" style="display:true;"><label class="mb-0">Transaction Hash</label><input type="text" class="form-control" name="txhash" placeholder="09dce..."></div>
                             <div class="pb-2"><label class="mb-0">Payment Evidence</label><input type="file" name="file" class="form-control"></div>
    						 <input class="btn btn-primary mt-2" type="submit" value="Send Evidence" name="BtnSendEvidencediamond">
						</form>
						
                    </div>
                </div>
            </div>
	
	
	
	    <div class="row ml-n2 mr-n2 textscale" id="new">
	        <br><br><br><hr>
        -Automated translated- 
        <hr><p>* Hallo Riddles &amp; Keno, kini kami hadir untuk mengembangkan bisnis lebih jauh lagi, dan mempermudahkan anda, melakukan transaksi lebih baik lagi,,</p>
        
        <p>* Oleh karena itu, kami memberi kesempatan kepada semua pengguna setia kami, untuk menjadi salah satu bagian dari kami </p>
        
        <p>* Dengan melakukan Pendaftaran sebagai agent deposit VIA LOCAL BANK INDONESIA, </p>
        
        <p>* Mengikuti program ini anda berhak mendapatkan 10% keuntungan dari setiap deposit yang dilakukan oleh user, melalui Agent anda.</p>
        
        <p>* Kami akan mengembangkan program Staking Pasif income, bermula dari 1% setiap hari dari nilai investasi anda, dengan minimum tingkat resiko </p>
        
        <p>* Bergabunglah menjadi bagian dari kami, </p>
        
        <p>* Hubungi salah satu agent kami, +6281266531733</p>
        
        
        Regards - Bluff.Global
        </div>
	
	
	
	
            <div id="form_visa" class="d-none">
                <div class="row">
                    <div class="col col-lg-3 col-md-3 col-sm-12 col-xs-12 col-12">
					<a class="card-deposit" href="#">
                            <div><img src="assets/img/Visa_Inc._logo.svg.png"><span>Credit / Debet Card</span></div>
                        </a><a class="d-block text-danger text-center" href="#" onclick="change_payment()">Change</a>
                        <a class="d-block text-info text-center" href="#" onclick="change_close()">Close</a></div>
                    <div class="col col-lg-9 col-md-9 col-sm-12 col-xs-12 col-12">
                        <h4 class="mb-0">Debit / Credit Card</h4>
                        <p>Please make payment according to the instructions below</p>
                        <hr class="mb-2"><img class="mb-2 radius-5" src="assets/img/visa_logo_all.png" style="height: 40px;">
                        <div class="pb-2"><label class="mb-0">Total Deposit</label><input type="text" class="form-control" placeholder="DMX."></div>
                        <div class="pb-2"><label class="mb-0">Credit / debit card number</label><input type="text" class="form-control" placeholder="Credit / debit card number"></div>
                        <div class="row m-0 border-element">
                            <div class="col col-lg-4 col-md-4 col-sm-4 col-xs-4 col-4 p-0">
                                <div class="pb-2"><input type="text" class="form-control" placeholder="MM"></div>
                            </div>
                            <div class="col col-lg-4 col-md-4 col-sm-4 col-xs-4 col-4 p-0">
                                <div class="pb-2"><input type="text" class="form-control" placeholder="YYYY"></div>
                            </div>
                            <div class="col col-lg-4 col-md-4 col-sm-4 col-xs-4 col-4 p-0">
                                <div class="pb-2"><input type="text" class="form-control" placeholder="CVV2"></div>
                            </div>
                        </div>
                        <div class="pb-2"><label class="mb-0">Card Holder's</label><input type="text" class="form-control" placeholder="Card Holder's Full Name"></div><button class="btn btn-primary mt-2 form-control" type="button">Deposit</button>
                    </div>
                </div>
            </div>
            
                    </div>
        
        
    
        
        
        
    </section>