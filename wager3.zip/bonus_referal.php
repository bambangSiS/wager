<section> 
	
	
	<div class="container bg-white min-vh-100 pt-3 pb-5">
		<div class="p-2 table-style">
		
	
	
		<div class="">
			<div class="" style="background: #3f47d5; padding:10px; padding-left:20px; padding-right:20px; border-radius:10px; ">
				<div class="d-flex align-items-center justify-content-between">
					<span class="text-dark"> <b> Converted From $USD  </b></span> 
					<div class="">
						<span class="text-dark"> L0 </span> 
						<span> - </span> 
						<span class="text-white"> L6 </span> 
					</div>
				</div>
				
				<div class="d-flex align-items-center"> 
									
					
					
						<h5 class="m-0 text-white"> 0</h5> 
						<small class="pl-2 text-white">  = 0 IDR (Today)</small> 
				</div>
				
				
				
				<span class="text-dark d=block mt-2"> <b> Entirety 30 Day </b> </span> 
					 
				<div class="d-flex align-items-center">
									
					
					
						<h5 class="m-0 text-white"> 0</h5> 
						<small class="pl-2 text-white">  = 0 IDR </small> 
				</div>
				<br>
				
				<div class="text-white" align="center">
				Your Referral Code = bambang  <p></p> 
			 
				</div>
			</div>
			 <br>
				<br>
				
						<link rel="stylesheet" href="https://riddle.dream888.net/assets/datatables/datatables.min.css">
						<link rel="stylesheet" href="https://riddle.dream888.net/assets/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
						<link rel="stylesheet" href="https://riddle.dream888.net/assets/datatables/Select-1.2.4/css/select.bootstrap4.min.css">  
						 
										<div class="table-responsive">
											<div id="tables_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer"><div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="tables_length"><label>Show <select name="tables_length" aria-controls="tables" class="form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="tables_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="tables"></label></div></div></div><div class="row"><div class="col-sm-12"><table id="tables" class="table table-striped dataTable no-footer" role="grid" aria-describedby="tables_info" style="width: 740px;">
												<thead>
												<tr role="row"><th class="sorting_desc" tabindex="0" aria-controls="tables" rowspan="1" colspan="1" aria-sort="descending" aria-label="Date: activate to sort column ascending" style="width: 158px;">Date</th><th class="sorting" tabindex="0" aria-controls="tables" rowspan="1" colspan="1" aria-label="Information : activate to sort column ascending" style="width: 295px;">Information </th><th class="sorting" tabindex="0" aria-controls="tables" rowspan="1" colspan="1" aria-label="Total : activate to sort column ascending" style="width: 161px;">Total </th></tr>
												</thead>
											<tbody><tr class="odd"><td valign="top" colspan="3" class="dataTables_empty">No matching records found</td></tr></tbody></table><div id="tables_processing" class="dataTables_processing card" style="display: none;">Processing...</div></div></div><div class="row"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="tables_info" role="status" aria-live="polite">Showing 0 to 0 of 0 entries (filtered from 70 total entries)</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="tables_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="tables_previous"><a href="#" aria-controls="tables" data-dt-idx="0" tabindex="0" class="page-link">Previous</a></li><li class="paginate_button page-item next disabled" id="tables_next"><a href="#" aria-controls="tables" data-dt-idx="1" tabindex="0" class="page-link">Next</a></li></ul></div></div></div></div> 
										</div> 

						<script src="https://riddle.dream888.net/assets/datatables/datatables.min.js"></script>
						<script src="https://riddle.dream888.net/assets/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
						<script src="https://riddle.dream888.net/assets/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>


						<script>  
						site ="https://riddle.dream888.net/";
						$(document).ready(function() {
						var tablex = $('#tables').dataTable( {
						 "bProcessing": true,
						 "bServerSide": true, 
						  
						 "order": [[0,'desc']], 
							"ajax" : { 
								url:  site+"server/bonus_referral.php?id=1) ;  ?>", 
								type:"POST"
							} ,
							
						 "aoColumns": [
							
							null,
							null,
							null, 
							
							
							
						 ]
						 } );
						 
						 } );
						 
						 
						 
						function table_reload(){
							$('#tables').DataTable().ajax.reload(null, false);
						}
						 

						</script> 

							
					
					 
		</div>
	
	</div>
	

</div></section>