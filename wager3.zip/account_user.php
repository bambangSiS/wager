<?php $ceklogin = isset ($_SESSION["userloginhighlow"]) ? $_SESSION["userloginhighlow"]:'';?>
            <?php if($ceklogin==''){?>
            <!--sign in-->
           <div class="text-center text-muted mb-4"><small>Please Sign in<br></small></div>
				<form method="post" enctype="multipart/form-data"> 
                    <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="text" name="username" placeholder="User Name">
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <div class="input-group input-group-alternative text-black">
                            <div class="input-group-prepend"><span class="input-group-text"><i class="la la-unlock m-0"></i></span></div>
							<input class="form-control" type="password" name="password" placeholder="Password">
                        </div>
                    </div>
                    <div class="custom-control custom-control-alternative custom-checkbox"><input type="checkbox" id="customCheckLogin" class="custom-control-input"><label class="custom-control-label" for="customCheckLogin"><span>Remember me<br></span></label></div>
                    <div class="text-center"><button class="btn btn-dark btn-min" name="login" type="button">Login</button></div>
                </form>
                <!--<div class="row mt-3">-->
                <!--    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6"><a href="#"><small class="text-light">Forgot Password<br></small></a></div>-->
                <!--    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6" align="right"><a href="register"><small class="text-light">Create new account<br></small></a></div>-->
                <!--</div>-->
                
            <!--signup-->
            <div class="text-center text-muted mb-4"><small>First Time<br></small></div>
				<form method="post" enctype="multipart/form-data"> 
				     <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="text" name="displayname" placeholder="Display Name" 
								value="<?php
                                        $a=array("Martha","Steven","Andreas","Jhon","Peter");
                                        $random_keys=array_rand($a,3);
                                        echo $a[$random_keys[0]];
                                        ?>">
                        </div>
                    </div>
                    <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="text" name="username" placeholder="User Name">
                        </div>
                    </div>
                     <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="email" name="email" placeholder="email">
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <div class="input-group input-group-alternative text-black">
                            <div class="input-group-prepend"><span class="input-group-text"><i class="la la-unlock m-0"></i></span></div>
							<input class="form-control" type="password" name="password" placeholder="Password">
                        </div>
                    </div>
                    <div class="text-center"><button class="btn btn-dark btn-min" name="login" type="button">Signin</button></div>
                </form>
                <!--<div class="row mt-3">-->
                <!--    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6"><a href="#"><small class="text-light">Forgot Password<br></small></a></div>-->
                <!--    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6" align="right"><a href="register"><small class="text-light">Have Account?sign in<br></small></a></div>-->
                <!--</div>-->
                
                <!--forgot password-->
           <div class="text-center text-muted mb-4"><small>Send me Password?<br></small></div>
				<form method="post" enctype="multipart/form-data"> 
                    <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend"><span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span></div>
								<input class="form-control" type="email" name="email" placeholder="your email">
                        </div>
                    </div>
                    <div class="text-center"><button class="btn btn-dark btn-min" name="login" type="button">send</button></div>
                </form>
                <!--<div class="row mt-3">-->
                <!--    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6"><a href="#"><small class="text-light">Sign in<br></small></a></div>-->
                <!--    <div class="col col-lg-6 col-md-6 col-sm-6 col-xs-6 col-6" align="right"><a href="register"><small class="text-light">Create new account<br></small></a></div>-->
                <!--</div>-->
                <?php }else{?>
                <div class="text-center text-muted mb-4"><small>Account<br></small></div>
                    <div class="form-group mb-3 text-black">
                        <div class="input-group input-group-alternative">
                            <div class="input-group-prepend">
                                <span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span>
                            </div>
                                <label>name</label><br>
                            <div class="input-group-prepend">
                                <span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span>
                            </div>
								<label>Username</label><br>
							<div class="input-group-prepend">
                                <span class="input-group-text text-black"><i class="la la-envelope m-0"></i></span>
                            </div>
								<label>Email</label><br>
                        </div>
                    </div>
                
                <?php }?>