$(document).ready(function() {
	
	function hide_all(){
	$('#col1').removeClass('active');
	$('#col2').removeClass('active');
	$('#col3').removeClass('active');
}


$('#id_toggle_1').click(function(){ hide_all(); $('#col1').addClass('active'); });
$('#id_toggle_2').click(function(){ hide_all(); $('#col2').addClass('active'); });
$('#id_toggle_3').click(function(){ hide_all(); $('#col3').addClass('active'); });
	
}); 