<div class="container mt-4 mb-4 radius-border bg-white pt-3 pb-3" style="margin-right: 250;margin-left: 250;" id="payment">
        <h4 class="text-monospace" align="center">Withdraw</h4>
        <hr>
        <form action="" method="post" enctype="multipart/form-data">
          <div class="row">
            <div class="col-50">
              <h3>Withdraw</h3>
              <label for="fname">
                <i class="fa fa-user"></i> Full Name </label>
              <input type="text" value="bambang" readonly="true">
              <div class="col-50">
                <h3>Payment</h3>
                <label for="fname">Accepted Cards</label>
                <div class="icon-containerw">
                  <img src="./image/accepted_diamond.png" width="60">
                  <img src="./image/bni.png" width="60">
                  <img src="./image/bri.png" width="40">
                  <img src="./image/cimb.png" width="80">
                  <img src="./image/mandiri.jpg" width="30">
                  <img src="./image/permata.jpg" width="20">
                </div>
                <label for="cname">Name on Card</label>
                <input type="text" id="cname" name="cardname" required="" placeholder="Bank Detail or Address Crypto">
                <label for="ccnum">Amount Withdraw</label>
                <input type="text" id="ccnum" name="amount" required="" placeholder="300000">
              </div>
            </div>
            <input style="margin-left: 10%;margin-right: 10%;" type="submit" value="Request Money" name="widtdrawbtn" class="btns">
        
      </div></form>
      </div>